#include "main.h"
#include "fatfs.h"
#include "usb_device.h"

SD_HandleTypeDef hsd1;

void SystemClock_Config(void);
static void MX_GPIO_Init(void);
static void MX_SDMMC1_SD_Init(void);

// LED 깜빡이기용
void blink_led(void)
{
  HAL_GPIO_TogglePin(GPIOC, GPIO_PIN_15);
  HAL_Delay(500);
}

#include "ff.h"
#include <stdio.h>
#include <string.h>
#include <ctype.h>

// 소문자 확장자 비교 함수
static int is_allowed_extension(const char *ext)
{
    if (!ext) return 0;

    // 허용 확장자 목록
    const char *allowed[] = {
        ".hwp", ".doc", ".docx",
        ".pdf", ".txt", ".rtf", ".odt",
        ".xls", ".xlsx",
        ".ppt", ".pptx",
        ".pages", ".md"
    };
    const int allowed_count = sizeof(allowed) / sizeof(allowed[0]);

    // 입력 확장자를 소문자로 변환
    char lower[16]; // ".docx" 최대 5자, 여유롭게 16 확보
    int i;
    for (i = 0; i < (int)(sizeof(lower) - 1) && ext[i]; ++i)
        lower[i] = tolower((unsigned char)ext[i]);
    lower[i] = '\0';

    // 배열과 비교
    for (i = 0; i < allowed_count; i++) {
        if (strcmp(lower, allowed[i]) == 0)
            return 1;
    }
    return 0;
}

// 재귀적으로 모든 폴더 순회하며 .hwp, .doc 제외 삭제
void delete_excluded_files_by_extension(const char *path)
{
  DIR dir;
  FILINFO fno;
  FRESULT res;

  res = f_opendir(&dir, path);
  if (res != FR_OK) {
    printf("디렉토리 열기 실패: %s (%d)\n", path, res);
    return;
  }

  while (1) {
    res = f_readdir(&dir, &fno);
    if (res != FR_OK || fno.fname[0] == 0)
      break;

    // 현재 항목 전체 경로 구성
    char full_path[256];
    snprintf(full_path, sizeof(full_path), "%s/%s", path, fno.fname);

    if (fno.fattrib & AM_DIR) {
      // 숨김/시스템/현재/상위 디렉터리 제외
      if (strcmp(fno.fname, ".") == 0 || strcmp(fno.fname, "..") == 0)
        continue;

      // 재귀적으로 하위 디렉터리 탐색
      delete_excluded_files_by_extension(full_path);
    } else {
      const char *ext = strrchr(fno.fname, '.');

      if (!is_allowed_extension(ext)) {
        // 삭제
        f_unlink(full_path);
        printf("삭제: %s\n", full_path);
      }
    }
  }

  f_closedir(&dir);
}

int main(void)
{
  HAL_Init();
  SystemClock_Config();

  MX_GPIO_Init();
  MX_SDMMC1_SD_Init();
  MX_FATFS_Init();

  FATFS fs;
  FRESULT fres;

  // SD 카드 마운트
  fres = f_mount(&fs, "", 1);
  if (fres == FR_OK)
  {
    printf("SD 카드 마운트 성공\n");
    delete_excluded_files_by_extension("/");  // 루트부터 시작
    MX_USB_DEVICE_Init();       // ✅ USB MSC 초기화는 반드시 이후에!
  }
  else
  {
    printf("SD 카드 마운트 실패: %d\n", fres);
    Error_Handler();
  }

  // 메인 루프: LED 깜빡이기
  while (1)
  {
    blink_led();
  }
}

/**
  * @brief SDMMC1 Initialization Function
  */
static void MX_SDMMC1_SD_Init(void)
{
  hsd1.Instance = SDMMC1;
  hsd1.Init.ClockEdge = SDMMC_CLOCK_EDGE_RISING;
  hsd1.Init.ClockPowerSave = SDMMC_CLOCK_POWER_SAVE_DISABLE;
  hsd1.Init.BusWide = SDMMC_BUS_WIDE_4B;
  hsd1.Init.HardwareFlowControl = SDMMC_HARDWARE_FLOW_CONTROL_ENABLE;
  hsd1.Init.ClockDiv = 5;  // 48 MHz 기준
  if (HAL_SD_Init(&hsd1) != HAL_OK)
  {
    Error_Handler();
  }
}

/**
  * @brief GPIO Initialization Function
  */
static void MX_GPIO_Init(void)
{
  __HAL_RCC_GPIOC_CLK_ENABLE();
  __HAL_RCC_GPIOA_CLK_ENABLE();
  __HAL_RCC_GPIOD_CLK_ENABLE();

  GPIO_InitTypeDef GPIO_InitStruct = {0};

  // PC15 (LED)
  GPIO_InitStruct.Pin = GPIO_PIN_15;
  GPIO_InitStruct.Mode = GPIO_MODE_OUTPUT_PP;
  GPIO_InitStruct.Pull = GPIO_NOPULL;
  GPIO_InitStruct.Speed = GPIO_SPEED_FREQ_LOW;
  HAL_GPIO_Init(GPIOC, &GPIO_InitStruct);
}

/**
  * @brief System Clock Configuration
  */
void SystemClock_Config(void)
{
  RCC_OscInitTypeDef RCC_OscInitStruct = {0};
  RCC_ClkInitTypeDef RCC_ClkInitStruct = {0};

  HAL_PWREx_ConfigSupply(PWR_LDO_SUPPLY);
  __HAL_PWR_VOLTAGESCALING_CONFIG(PWR_REGULATOR_VOLTAGE_SCALE3);
  while(!__HAL_PWR_GET_FLAG(PWR_FLAG_VOSRDY)) {}

  RCC_OscInitStruct.OscillatorType = RCC_OSCILLATORTYPE_HSE;
  RCC_OscInitStruct.HSEState = RCC_HSE_ON;
  RCC_OscInitStruct.PLL.PLLState = RCC_PLL_ON;
  RCC_OscInitStruct.PLL.PLLSource = RCC_PLLSOURCE_HSE;
  RCC_OscInitStruct.PLL.PLLM = 2;
  RCC_OscInitStruct.PLL.PLLN = 12;
  RCC_OscInitStruct.PLL.PLLP = 2;
  RCC_OscInitStruct.PLL.PLLQ = 3;
  RCC_OscInitStruct.PLL.PLLR = 2;
  RCC_OscInitStruct.PLL.PLLRGE = RCC_PLL1VCIRANGE_3;
  RCC_OscInitStruct.PLL.PLLVCOSEL = RCC_PLL1VCOWIDE;
  RCC_OscInitStruct.PLL.PLLFRACN = 0;
  if (HAL_RCC_OscConfig(&RCC_OscInitStruct) != HAL_OK)
    Error_Handler();

  RCC_ClkInitStruct.ClockType = RCC_CLOCKTYPE_HCLK | RCC_CLOCKTYPE_SYSCLK |
                                RCC_CLOCKTYPE_PCLK1 | RCC_CLOCKTYPE_PCLK2 |
                                RCC_CLOCKTYPE_D3PCLK1 | RCC_CLOCKTYPE_D1PCLK1;
  RCC_ClkInitStruct.SYSCLKSource = RCC_SYSCLKSOURCE_PLLCLK;
  RCC_ClkInitStruct.SYSCLKDivider = RCC_SYSCLK_DIV1;
  RCC_ClkInitStruct.AHBCLKDivider = RCC_HCLK_DIV1;
  RCC_ClkInitStruct.APB3CLKDivider = RCC_APB3_DIV2;
  RCC_ClkInitStruct.APB1CLKDivider = RCC_APB1_DIV2;
  RCC_ClkInitStruct.APB2CLKDivider = RCC_APB2_DIV2;
  RCC_ClkInitStruct.APB4CLKDivider = RCC_APB4_DIV2;

  if (HAL_RCC_ClockConfig(&RCC_ClkInitStruct, FLASH_LATENCY_2) != HAL_OK)
    Error_Handler();
}

void Error_Handler(void)
{
  __disable_irq();
  while (1)
  {
    HAL_GPIO_TogglePin(GPIOC, GPIO_PIN_15);
    HAL_Delay(100);  // 빠르게 깜빡여서 오류 표시
  }
}
