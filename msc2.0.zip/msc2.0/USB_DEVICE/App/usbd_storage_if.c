/* USER CODE BEGIN Header */
/**
  ******************************************************************************
  * @file           : usbd_storage_if.c
  * @brief          : USB MSC Storage interface implementation using SDMMC1.
  ******************************************************************************
  */
/* USER CODE END Header */

/* Includes ------------------------------------------------------------------*/
#include "usbd_storage_if.h"
#include "main.h"  // hsd1 선언 위치

extern SD_HandleTypeDef hsd1;

/* Private defines ---------------------------------------------------------- */
#define STORAGE_LUN_NBR                  1
#define STORAGE_BLK_SIZ                  512  // 512 bytes per sector

/* USB Mass storage Standard Inquiry Data */
const int8_t STORAGE_Inquirydata_HS[] = {
  0x00, 0x80, 0x02, 0x02,
  (STANDARD_INQUIRY_DATA_LEN - 5), 0x00, 0x00, 0x00,
  'S','T','M',' ',' ',' ',' ',' ',  // Manufacturer
  'S','D',' ','S','t','o','r','e',  // Product
  ' ',' ',' ',' ',' ',' ',' ',' ',
  '1','.','0','0'                   // Version
};

/* Private function prototypes ----------------------------------------------- */
static int8_t STORAGE_Init_HS(uint8_t lun);
static int8_t STORAGE_GetCapacity_HS(uint8_t lun, uint32_t *block_num, uint16_t *block_size);
static int8_t STORAGE_IsReady_HS(uint8_t lun);
static int8_t STORAGE_IsWriteProtected_HS(uint8_t lun);
static int8_t STORAGE_Read_HS(uint8_t lun, uint8_t *buf, uint32_t blk_addr, uint16_t blk_len);
static int8_t STORAGE_Write_HS(uint8_t lun, uint8_t *buf, uint32_t blk_addr, uint16_t blk_len);
static int8_t STORAGE_GetMaxLun_HS(void);

/* USB MSC interface structure */
USBD_StorageTypeDef USBD_Storage_Interface_fops_HS =
{
  STORAGE_Init_HS,
  STORAGE_GetCapacity_HS,
  STORAGE_IsReady_HS,
  STORAGE_IsWriteProtected_HS,
  STORAGE_Read_HS,
  STORAGE_Write_HS,
  STORAGE_GetMaxLun_HS,
  (int8_t *)STORAGE_Inquirydata_HS
};

/* Function implementations -------------------------------------------------- */

static int8_t STORAGE_Init_HS(uint8_t lun)
{
	 return USBD_OK;
}

static int8_t STORAGE_GetCapacity_HS(uint8_t lun, uint32_t *block_num, uint16_t *block_size)
{
  HAL_SD_CardInfoTypeDef cardInfo;

  if (HAL_SD_GetCardInfo(&hsd1, &cardInfo) != HAL_OK)
    return USBD_FAIL;

  *block_num = cardInfo.LogBlockNbr - 1;
  *block_size = cardInfo.LogBlockSize;

  return USBD_OK;
}

static int8_t STORAGE_IsReady_HS(uint8_t lun)
{
  return (HAL_SD_GetCardState(&hsd1) == HAL_SD_CARD_TRANSFER) ? USBD_OK : USBD_FAIL;
}

static int8_t STORAGE_IsWriteProtected_HS(uint8_t lun)
{
  return USBD_OK;  // SD 카드 쓰기 가능
}

static int8_t STORAGE_Read_HS(uint8_t lun, uint8_t *buf, uint32_t blk_addr, uint16_t blk_len)
{
  if (HAL_SD_ReadBlocks(&hsd1, buf, blk_addr, blk_len, HAL_MAX_DELAY) != HAL_OK)
    return USBD_FAIL;

  while (HAL_SD_GetCardState(&hsd1) != HAL_SD_CARD_TRANSFER);

  return USBD_OK;
}

static int8_t STORAGE_Write_HS(uint8_t lun, uint8_t *buf, uint32_t blk_addr, uint16_t blk_len)
{
  if (HAL_SD_WriteBlocks(&hsd1, buf, blk_addr, blk_len, HAL_MAX_DELAY) != HAL_OK)
    return USBD_FAIL;

  while (HAL_SD_GetCardState(&hsd1) != HAL_SD_CARD_TRANSFER);

  return USBD_OK;
}

static int8_t STORAGE_GetMaxLun_HS(void)
{
  return (STORAGE_LUN_NBR - 1);
}
